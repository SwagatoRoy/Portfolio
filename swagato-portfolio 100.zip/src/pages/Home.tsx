import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { 
  Search, ShoppingCart, Target, Youtube, Image as ImageIcon, 
  Activity, LayoutTemplate, Settings, Menu, X, ArrowRight,
  ChevronLeft, ChevronRight, RefreshCw, Phone, BarChart3,
  MapPin, Briefcase
} from "lucide-react";
import { FaWhatsapp, FaFacebook, FaLinkedin } from "react-icons/fa";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";

import profileImg from "@assets/shtnmtmstuje6ui76i7i48_1777315466403.jpg";
import cert1 from "@assets/srnstyns678957kmjd_1777315456700.png";
import cert2 from "@assets/synjsjtynwyjt3784678_1777315449512.jpeg";

import cs1 from "@assets/google-ads-graphs-800_1777315392221.png";
import cs2 from "@assets/aigjtrh42y6826_1777315403125.jpeg";
import cs3 from "@assets/srtjyt35738y_1777315414036.jpeg";
import cs4 from "@assets/avqnanbaonborst6357_1777315424078.jpeg";
import cs5 from "@assets/loadkaanankhbrt356_1777315431313.jpg";
import cs6 from "@assets/kjkngbnb536u_1777315441535.png";

const NAV_LINKS = [
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Industries", href: "#industries" },
  { label: "Case Studies", href: "#case-studies" },
  { label: "Process", href: "#process" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "FAQ", href: "#faq" },
];

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const GOOGLE_FORM_ACTION =
  "https://docs.google.com/forms/d/e/1FAIpQLSelEKNhN9UUKVuXm8o0RaMMoe1RjC_6Sw7HW7jt5Y2KTk9lpQ/formResponse";

const FORM_ENTRY_IDS = {
  name: "entry.634034884",
  businessName: "entry.155167072",
  phone: "entry.257180916",
  email: "entry.1195438204",
  message: "entry.671250911",
} as const;

const EMPTY_FORM = {
  name: "",
  businessName: "",
  phone: "",
  email: "",
  message: "",
};

type LightboxImage = { src: string; caption: string };

const CASE_STUDY_IMAGES: LightboxImage[] = [
  { src: cs1, caption: "E-commerce Sales Campaign" },
  { src: cs2, caption: "E-commerce Sales Campaign" },
  { src: cs3, caption: "Local Service Lead Generation Campaign" },
  { src: cs4, caption: "Home Service Lead Generation Campaign" },
  { src: cs5, caption: "Local Service Lead Generation Campaign" },
  { src: cs6, caption: "E-commerce Sales Campaign" },
];

const CERTIFICATE_IMAGES: LightboxImage[] = [
  { src: cert2, caption: "Certified Google Ads Specialist" },
  { src: cert1, caption: "Certified Google Ads Specialist" },
];

export default function Home() {
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState(EMPTY_FORM);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [lightbox, setLightbox] = useState<{
    images: LightboxImage[];
    index: number;
  } | null>(null);

  const closeLightbox = () => setLightbox(null);
  const showPrev = () =>
    setLightbox((l) =>
      l === null
        ? null
        : { ...l, index: (l.index - 1 + l.images.length) % l.images.length }
    );
  const showNext = () =>
    setLightbox((l) =>
      l === null ? null : { ...l, index: (l.index + 1) % l.images.length }
    );

  useEffect(() => {
    if (lightbox === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeLightbox();
      else if (e.key === "ArrowLeft") showPrev();
      else if (e.key === "ArrowRight") showNext();
    };
    window.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [lightbox]);

  const handleFieldChange =
    (field: keyof typeof EMPTY_FORM) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setFormData((prev) => ({ ...prev, [field]: e.target.value }));
    };

  const handleContactSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (isSubmitting) return;
    setIsSubmitting(true);
    setSubmitSuccess(false);

    try {
      const payload = new FormData();
      payload.append(FORM_ENTRY_IDS.name, formData.name);
      payload.append(FORM_ENTRY_IDS.businessName, formData.businessName);
      payload.append(FORM_ENTRY_IDS.phone, formData.phone);
      payload.append(FORM_ENTRY_IDS.email, formData.email);
      payload.append(FORM_ENTRY_IDS.message, formData.message);

      // Google Forms accepts cross-origin POSTs but doesn't expose the response.
      // no-cors gets the submission through without redirecting or reloading.
      await fetch(GOOGLE_FORM_ACTION, {
        method: "POST",
        mode: "no-cors",
        body: payload,
      });

      setFormData(EMPTY_FORM);
      setSubmitSuccess(true);
      toast({
        title: "Message sent",
        description: "I will contact you soon.",
      });
    } catch {
      toast({
        title: "Something went wrong",
        description: "Please try again, or reach out via WhatsApp or email.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-[100dvh] bg-background text-foreground selection:bg-primary/30">
      
      {/* HEADER */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#0D0A1F]/70 backdrop-blur-xl border-b border-white/5 shadow-[0_1px_0_0_rgba(255,255,255,0.03)]">
        <div className="container mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
          {/* LOGO */}
          <a
            href="#hero"
            data-testid="link-logo"
            className="group flex items-center gap-2.5 text-white"
          >
            <span className="relative w-9 h-9 rounded-full bg-gradient-to-br from-primary to-primary/40 ring-1 ring-white/10 shadow-[0_0_20px_rgba(124,58,237,0.4)] flex items-center justify-center text-sm font-bold transition-shadow duration-300 group-hover:shadow-[0_0_28px_rgba(124,58,237,0.6)]">
              S
            </span>
            <span className="text-base md:text-lg font-semibold tracking-tight">
              Swagato Roy
            </span>
          </a>

          {/* DESKTOP NAV */}
          <nav className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                data-testid={`link-nav-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                className="group relative px-4 py-2 text-sm font-medium text-white/65 hover:text-white transition-colors duration-300"
              >
                {link.label}
                <span
                  aria-hidden="true"
                  className="pointer-events-none absolute left-4 right-4 -bottom-0.5 h-px origin-left scale-x-0 bg-gradient-to-r from-primary via-primary/80 to-primary/0 transition-transform duration-300 ease-out group-hover:scale-x-100"
                />
              </a>
            ))}
          </nav>

          {/* DESKTOP CTA */}
          <motion.div
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.97 }}
            transition={{ type: "spring", stiffness: 300, damping: 22 }}
            className="hidden lg:block"
          >
            <Button
              onClick={scrollToContact}
              data-testid="button-nav-cta"
              className="rounded-full px-6 h-11 text-sm font-medium bg-gradient-to-r from-primary to-[#9F5BFF] hover:from-[#8B45F0] hover:to-[#A968FF] text-white border-0 shadow-[0_0_20px_rgba(124,58,237,0.45)] hover:shadow-[0_8px_30px_rgba(124,58,237,0.65)] transition-shadow duration-300"
            >
              Book a Free Call
            </Button>
          </motion.div>

          {/* MOBILE MENU */}
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                data-testid="button-menu-toggle"
                className="lg:hidden text-white hover:bg-white/5"
              >
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="bg-[#0D0A1F]/95 backdrop-blur-xl border-l border-white/10 w-[300px] p-6"
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center gap-2.5 mt-2 mb-10">
                  <span className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-primary/40 ring-1 ring-white/10 flex items-center justify-center text-sm font-bold text-white">
                    S
                  </span>
                  <span className="text-base font-semibold text-white tracking-tight">
                    Swagato Roy
                  </span>
                </div>

                <nav className="flex flex-col gap-1">
                  {NAV_LINKS.map((link, i) => (
                    <motion.a
                      key={link.label}
                      href={link.href}
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05, duration: 0.3 }}
                      data-testid={`link-mobile-nav-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                      className="text-base font-medium text-white/80 hover:text-primary px-3 py-3 rounded-lg hover:bg-white/5 transition-colors duration-300"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {link.label}
                    </motion.a>
                  ))}
                </nav>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.35, duration: 0.3 }}
                  className="mt-8"
                >
                  <Button
                    onClick={() => {
                      scrollToContact();
                      setIsMobileMenuOpen(false);
                    }}
                    data-testid="button-mobile-cta"
                    className="w-full rounded-full h-12 text-sm font-medium bg-gradient-to-r from-primary to-[#9F5BFF] hover:from-[#8B45F0] hover:to-[#A968FF] text-white border-0 shadow-[0_0_20px_rgba(124,58,237,0.45)]"
                  >
                    Book a Free Call
                  </Button>
                </motion.div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      <main className="pt-20">
        
        {/* SECTION 1 — HERO */}
        <section id="hero" className="relative pt-24 pb-32 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="flex flex-col md:flex-row items-center gap-12 lg:gap-24">
              <motion.div 
                initial="hidden" animate="visible" variants={staggerContainer}
                className="flex-1 text-center md:text-left"
              >
                <motion.div variants={fadeInUp} className="mb-6 inline-flex items-center">
                  <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20 px-4 py-1.5 rounded-full border border-primary/20">
                    Google Ads Certified
                  </Badge>
                </motion.div>
                <motion.h1 variants={fadeInUp} className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 text-white">
                  I Help E-Commerce Brands, Local Businesses & Service Companies Get More Leads with Data-Driven Google Ads
                </motion.h1>
                <motion.p variants={fadeInUp} className="text-lg md:text-xl text-white/70 mb-10 max-w-2xl mx-auto md:mx-0">
                  I build and optimize high-performing Google Ads campaigns that generate sales, leads, and consistent business growth.
                </motion.p>
                <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4">
                  <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 260, damping: 22 }} className="w-full sm:w-auto">
                    <Button size="lg" onClick={scrollToContact} className="w-full sm:w-auto rounded-full px-8 h-14 text-base shadow-[0_0_20px_rgba(124,58,237,0.4)] hover:shadow-[0_10px_40px_rgba(124,58,237,0.6)] transition-shadow">
                      Book a Free Call
                    </Button>
                  </motion.div>
                  <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 260, damping: 22 }} className="w-full sm:w-auto">
                    <Button size="lg" variant="outline" onClick={scrollToContact} className="w-full sm:w-auto rounded-full px-8 h-14 text-base border-white/20 hover:bg-white/5 hover:border-primary/40 hover:shadow-[0_10px_30px_rgba(124,58,237,0.25)] transition-all">
                      Get a Free Audit
                    </Button>
                  </motion.div>
                </motion.div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="w-[280px] md:w-[400px] flex-shrink-0"
              >
                <div className="relative aspect-square rounded-full p-2 bg-gradient-to-br from-primary/40 to-transparent shadow-[0_0_40px_rgba(124,58,237,0.3)]">
                  <div className="absolute inset-0 rounded-full border border-primary/30" />
                  <img 
                    src={profileImg} 
                    alt="Swagato Roy Profile" 
                    className="w-full h-full object-cover rounded-full"
                    loading="eager"
                  />
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* SECTION 2 — ABOUT */}
        <section id="about" className="py-24 bg-white/[0.02] border-y border-white/5 relative">
          <div className="container mx-auto px-4 md:px-6">
            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-100px" }} variants={staggerContainer}
              className="max-w-4xl mx-auto text-center"
            >
              <motion.h2 variants={fadeInUp} className="text-3xl font-bold mb-6 text-white">About Me</motion.h2>
              <motion.p variants={fadeInUp} className="text-lg text-white/70 mb-16 leading-relaxed">
                As a specialized Google Ads Expert, I partner with e-commerce, local, and service-based businesses to transform their ad spend into measurable profit. I don't just chase clicks; I engineer data-driven campaigns designed to scale your sales and fill your pipeline with high-quality leads.
              </motion.p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-2xl mx-auto">
                {[
                  { value: "3+", label: "Years Experience" },
                  { value: "50+", label: "Campaigns Managed" }
                ].map((stat, i) => (
                  <motion.div
                    key={i}
                    variants={fadeInUp}
                    whileHover={{ y: -6 }}
                    transition={{ type: "spring", stiffness: 260, damping: 22 }}
                    data-testid={`card-stat-${i}`}
                    className="group relative rounded-2xl p-px bg-gradient-to-b from-white/15 via-white/5 to-transparent hover:from-primary/50 hover:via-primary/20 transition-colors duration-300"
                  >
                    <div className="relative h-full rounded-2xl bg-[#13102A]/80 backdrop-blur-sm p-8 flex flex-col items-center justify-center shadow-[0_4px_30px_rgba(0,0,0,0.3)] group-hover:shadow-[0_8px_40px_rgba(124,58,237,0.25)] transition-shadow duration-300">
                      <div className="text-4xl font-bold text-primary mb-2">{stat.value}</div>
                      <div className="text-sm font-medium text-white/60 uppercase tracking-wider">{stat.label}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* SECTION 3 — CERTIFICATION */}
        <section id="certification" className="py-24">
          <div className="container mx-auto px-4 md:px-6">
            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}
              className="text-center max-w-3xl mx-auto mb-16"
            >
              <motion.h2 variants={fadeInUp} className="text-3xl md:text-4xl font-bold text-white mb-4">Certified Google Ads Specialist</motion.h2>
              <motion.p variants={fadeInUp} className="text-white/60 text-lg">Industry-recognized expertise to ensure your campaigns follow best practices and deliver maximum ROI.</motion.p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {CERTIFICATE_IMAGES.map((cert, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 * (i + 1) }}
                  whileHover={{ y: -6 }}
                  className="group relative rounded-2xl p-px bg-gradient-to-b from-white/15 via-white/5 to-transparent hover:from-primary/50 hover:via-primary/20 transition-colors duration-300"
                >
                  <div className="relative h-full rounded-2xl bg-[#13102A]/80 backdrop-blur-sm p-4 shadow-[0_4px_30px_rgba(0,0,0,0.3)] group-hover:shadow-[0_8px_40px_rgba(124,58,237,0.25)] transition-shadow duration-300">
                    <button
                      type="button"
                      onClick={() => setLightbox({ images: CERTIFICATE_IMAGES, index: i })}
                      aria-label={`View full size: ${cert.caption}`}
                      data-testid={`button-certificate-${i}`}
                      className="block w-full text-left cursor-zoom-in focus:outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-xl"
                    >
                      <div className="aspect-[4/3] rounded-xl overflow-hidden relative bg-black">
                        <img
                          src={cert.src}
                          alt={cert.caption}
                          className="w-full h-full object-contain"
                          loading="lazy"
                        />
                      </div>
                      <p className="text-center mt-4 font-medium text-white/80">{cert.caption}</p>
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* SECTION 4 — SERVICES */}
        <section id="services" className="py-24 bg-white/[0.02] border-y border-white/5">
          <div className="container mx-auto px-4 md:px-6">
            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}
              className="text-center max-w-3xl mx-auto mb-16"
            >
              <motion.h2 variants={fadeInUp} className="text-3xl md:text-4xl font-bold text-white mb-4">My Services</motion.h2>
              <motion.p variants={fadeInUp} className="text-white/60 text-lg">Comprehensive Google Ads management tailored to your specific business goals.</motion.p>
            </motion.div>

            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              {[
                { icon: Search, title: "Google Search Ads", desc: "High-intent search campaigns that capture demand" },
                { icon: Target, title: "Performance Max Campaigns", desc: "AI-driven campaigns across Google's full network" },
                { icon: Youtube, title: "YouTube Ads", desc: "Video campaigns for awareness and direct response" },
                { icon: ImageIcon, title: "Display Ads", desc: "Reach new audiences through visually engaging banner ads across Google's Display Network." },
                { icon: RefreshCw, title: "Remarketing Campaigns", desc: "Re-engage previous visitors and convert warm audiences with targeted remarketing strategies." },
                { icon: Activity, title: "Conversion Tracking & GA4 Setup", desc: "Accurate measurement from click to sale" },
                { icon: Phone, title: "Call Tracking Setup", desc: "Attribute every call to the right campaign and keyword to measure true ROI." },
                { icon: LayoutTemplate, title: "Landing Page Strategy", desc: "Conversion-focused page recommendations" },
                { icon: Settings, title: "Audit & Optimization", desc: "Account audits, keyword cleanup, bid strategy tuning" },
                { icon: BarChart3, title: "Monthly Optimization & Reporting", desc: "Ongoing tuning plus clear monthly reports with insights and next action steps." },
              ].map((service, i) => (
                <motion.div
                  key={i}
                  variants={fadeInUp}
                  whileHover={{ y: -6 }}
                  transition={{ type: "spring", stiffness: 260, damping: 22 }}
                  data-testid={`card-service-${i}`}
                  className="group relative rounded-2xl p-px bg-gradient-to-b from-white/15 via-white/5 to-transparent hover:from-primary/50 hover:via-primary/20 transition-colors duration-300 h-full"
                >
                  <div className="relative h-full rounded-2xl bg-[#13102A]/80 backdrop-blur-sm p-6 shadow-[0_4px_30px_rgba(0,0,0,0.3)] group-hover:shadow-[0_8px_40px_rgba(124,58,237,0.25)] transition-shadow duration-300">
                    <div className="relative mb-6 w-12 h-12">
                      <div
                        aria-hidden="true"
                        className="absolute inset-0 rounded-lg bg-primary/30 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      />
                      <div className="relative w-12 h-12 rounded-lg bg-primary/20 text-primary flex items-center justify-center ring-1 ring-white/5">
                        <service.icon className="w-6 h-6" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2 tracking-tight">{service.title}</h3>
                    <p className="text-sm text-white/60 leading-relaxed">{service.desc}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* SECTION 5 — INDUSTRIES */}
        <section id="industries" className="relative py-24 overflow-hidden">
          {/* ambient background glow */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 -z-10"
          >
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] max-w-3xl aspect-square rounded-full bg-primary/10 blur-[120px]" />
          </div>

          <div className="container mx-auto px-4 md:px-6">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="text-center max-w-3xl mx-auto mb-16"
            >
              <motion.h2
                variants={fadeInUp}
                className="text-3xl md:text-4xl lg:text-5xl font-bold text-white tracking-tight mb-4"
              >
                Industries I Serve
              </motion.h2>
              <motion.p
                variants={fadeInUp}
                className="text-white/60 text-base md:text-lg"
              >
                Tailored strategies for specific business models.
              </motion.p>
            </motion.div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto"
            >
              {[
                {
                  icon: ShoppingCart,
                  title: "E-commerce Brands",
                  desc: "Scaling revenue, lowering CPA, and maximizing ROAS through Shopping and Performance Max campaigns.",
                },
                {
                  icon: MapPin,
                  title: "Local Businesses",
                  desc: "Driving foot traffic, phone calls, and local inquiries to dominate your neighborhood market.",
                },
                {
                  icon: Briefcase,
                  title: "Service-Based Companies",
                  desc: "Generating highly qualified leads that convert into high-ticket clients.",
                },
              ].map((ind, i) => (
                <motion.div
                  key={i}
                  variants={fadeInUp}
                  whileHover={{ y: -6 }}
                  transition={{ type: "spring", stiffness: 260, damping: 22 }}
                  data-testid={`card-industry-${i}`}
                  className="group relative rounded-2xl p-px bg-gradient-to-b from-white/15 via-white/5 to-transparent hover:from-primary/50 hover:via-primary/20 transition-colors duration-300"
                >
                  <div className="relative h-full rounded-2xl bg-[#13102A]/80 backdrop-blur-sm px-8 py-10 text-center flex flex-col items-center shadow-[0_4px_30px_rgba(0,0,0,0.3)] group-hover:shadow-[0_8px_40px_rgba(124,58,237,0.25)] transition-shadow duration-300">
                    {/* Circular gradient icon */}
                    <div className="relative mb-6">
                      <div
                        aria-hidden="true"
                        className="absolute inset-0 rounded-full bg-primary/30 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      />
                      <div className="relative w-16 h-16 rounded-full bg-gradient-to-br from-primary to-primary/40 flex items-center justify-center ring-1 ring-white/10 shadow-[0_0_20px_rgba(124,58,237,0.35)]">
                        <ind.icon className="w-7 h-7 text-white" strokeWidth={2} />
                      </div>
                    </div>

                    <h3 className="text-xl font-semibold text-white mb-3 tracking-tight">
                      {ind.title}
                    </h3>
                    <p className="text-white/65 text-sm md:text-base leading-relaxed">
                      {ind.desc}
                    </p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* SECTION 6 — CASE STUDIES */}
        <section id="case-studies" className="py-24 bg-white/[0.02] border-y border-white/5">
          <div className="container mx-auto px-4 md:px-6">
            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}
              className="text-center max-w-3xl mx-auto mb-16"
            >
              <motion.h2 variants={fadeInUp} className="text-3xl md:text-4xl font-bold text-white mb-4">Proven Results</motion.h2>
              <motion.p variants={fadeInUp} className="text-white/60 text-lg">Real campaign results from across e-commerce, local, and service industries.</motion.p>
            </motion.div>

            {/* Screenshot Gallery — click any image to view full size */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {CASE_STUDY_IMAGES.map((img, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -6 }}
                  className="group relative rounded-2xl p-px bg-gradient-to-b from-white/15 via-white/5 to-transparent hover:from-primary/50 hover:via-primary/20 transition-colors duration-300"
                >
                  <div className="relative h-full rounded-2xl overflow-hidden bg-[#13102A]/80 backdrop-blur-sm shadow-[0_4px_30px_rgba(0,0,0,0.3)] group-hover:shadow-[0_8px_40px_rgba(124,58,237,0.25)] transition-shadow duration-300">
                    <button
                      type="button"
                      onClick={() => setLightbox({ images: CASE_STUDY_IMAGES, index: i })}
                      aria-label={`View full size: ${img.caption}`}
                      data-testid={`button-case-study-${i}`}
                      className="block w-full text-left cursor-zoom-in focus:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                    >
                      <div className="aspect-[4/3] overflow-hidden bg-black">
                        <img
                          src={img.src}
                          alt={img.caption}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          loading="lazy"
                        />
                      </div>
                      <div className="p-4">
                        <p className="text-sm font-medium text-white/80">{img.caption}</p>
                      </div>
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* SECTION 7 — MY PROCESS */}
        <section id="process" className="relative py-24 overflow-hidden scroll-mt-24">
          {/* ambient background glow */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 -z-10"
          >
            <div className="absolute left-1/4 top-1/2 -translate-y-1/2 w-[500px] aspect-square rounded-full bg-primary/10 blur-[120px]" />
          </div>

          <div className="container mx-auto px-4 md:px-6">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="text-center max-w-3xl mx-auto mb-16"
            >
              <motion.h2
                variants={fadeInUp}
                className="text-3xl md:text-4xl lg:text-5xl font-bold text-white tracking-tight mb-4"
              >
                My Process
              </motion.h2>
              <motion.p
                variants={fadeInUp}
                className="text-white/60 text-base md:text-lg"
              >
                A systematic approach to scaling your business with Google Ads.
              </motion.p>
            </motion.div>

            <div className="relative max-w-3xl mx-auto">
              {/* Continuous gradient timeline line */}
              <div
                aria-hidden="true"
                className="absolute left-7 md:left-8 top-8 bottom-8 w-px bg-gradient-to-b from-primary/60 via-primary/30 to-transparent"
              />

              <div className="flex flex-col gap-10 md:gap-14">
                {[
                  {
                    num: "01",
                    title: "Free Audit",
                    desc: "I review your account, competitors, and goals.",
                  },
                  {
                    num: "02",
                    title: "Strategy & Setup",
                    desc: "Campaign structure, keywords, creative, conversion tracking.",
                  },
                  {
                    num: "03",
                    title: "Tracking & Optimization",
                    desc: "Continuous testing, scaling what works, cutting what doesn't.",
                  },
                ].map((step, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -24 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, margin: "-80px" }}
                    transition={{ delay: i * 0.15, duration: 0.6, ease: "easeOut" }}
                    data-testid={`step-process-${i}`}
                    className="group relative flex items-start gap-5 md:gap-7"
                  >
                    {/* Number badge */}
                    <div className="relative flex-shrink-0">
                      <div
                        aria-hidden="true"
                        className="absolute inset-0 rounded-full bg-primary/40 blur-xl opacity-60 group-hover:opacity-100 transition-opacity duration-300"
                      />
                      <div className="relative w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-to-br from-primary to-primary/40 ring-1 ring-white/10 shadow-[0_0_24px_rgba(124,58,237,0.45)] flex items-center justify-center text-white font-bold text-base md:text-lg tracking-tight">
                        {step.num}
                      </div>
                    </div>

                    {/* Content card */}
                    <motion.div
                      whileHover={{ y: -4 }}
                      transition={{ type: "spring", stiffness: 260, damping: 22 }}
                      className="flex-1 rounded-2xl p-px bg-gradient-to-b from-white/15 via-white/5 to-transparent group-hover:from-primary/40 group-hover:via-primary/15 transition-colors duration-300"
                    >
                      <div className="rounded-2xl bg-[#13102A]/80 backdrop-blur-sm px-6 py-5 md:px-8 md:py-6 shadow-[0_4px_30px_rgba(0,0,0,0.3)] group-hover:shadow-[0_8px_40px_rgba(124,58,237,0.2)] transition-shadow duration-300">
                        <h3 className="text-xl md:text-2xl font-semibold text-white mb-2 tracking-tight">
                          {step.title}
                        </h3>
                        <p className="text-white/65 text-sm md:text-base leading-relaxed">
                          {step.desc}
                        </p>
                      </div>
                    </motion.div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 8 — TESTIMONIALS */}
        <section id="testimonials" className="py-24 bg-white/[0.02] border-y border-white/5">
          <div className="container mx-auto px-4 md:px-6">
            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}
              className="text-center max-w-3xl mx-auto mb-16"
            >
              <motion.h2 variants={fadeInUp} className="text-3xl md:text-4xl font-bold text-white mb-4">Client Success</motion.h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {[
                { 
                  quote: "Swagato completely turned around our Shopify store's ROAS. Within a month we were seeing consistent, profitable sales we hadn't achieved before.", 
                  name: "Sarah J.", type: "E-commerce Founder" 
                },
                { 
                  quote: "Our clinic is now booked weeks in advance. The local search campaigns generate high-quality phone calls every single day.", 
                  name: "Dr. Michael T.", type: "Dental Clinic Owner" 
                },
                { 
                  quote: "The quality of leads from our new campaigns is night and day. We're wasting far less time on bad prospects and closing more deals.", 
                  name: "David R.", type: "HVAC Service Owner" 
                }
              ].map((test, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -6 }}
                  data-testid={`card-testimonial-${i}`}
                  className="group relative rounded-2xl p-px bg-gradient-to-b from-white/15 via-white/5 to-transparent hover:from-primary/50 hover:via-primary/20 transition-colors duration-300 h-full"
                >
                  <div className="relative h-full rounded-2xl bg-[#13102A]/80 backdrop-blur-sm p-8 flex flex-col shadow-[0_4px_30px_rgba(0,0,0,0.3)] group-hover:shadow-[0_8px_40px_rgba(124,58,237,0.25)] transition-shadow duration-300">
                    <div className="flex gap-1 mb-6 text-primary">
                      {[1, 2, 3, 4, 5].map(star => (
                        <svg key={star} className="w-5 h-5 fill-current" viewBox="0 0 20 20">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <p className="text-white/80 italic mb-8 flex-grow">"{test.quote}"</p>
                    <div>
                      <p className="font-bold text-white">{test.name}</p>
                      <p className="text-sm text-white/50">{test.type}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* SECTION 9 — FAQ */}
        <section id="faq" className="py-24">
          <div className="container mx-auto px-4 md:px-6 max-w-3xl">
            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}
              className="text-center mb-16"
            >
              <motion.h2 variants={fadeInUp} className="text-3xl md:text-4xl font-bold text-white mb-4">Frequently Asked Questions</motion.h2>
            </motion.div>

            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1" className="border-white/10">
                  <AccordionTrigger className="text-left text-lg font-medium text-white hover:text-primary">How much do I need to spend on Google Ads to see results?</AccordionTrigger>
                  <AccordionContent className="text-white/70 text-base leading-relaxed">
                    This depends heavily on your industry and competition. For local businesses, you can often start seeing leads with $1,000-$1,500/month. E-commerce brands usually require a higher starting budget to test properly and gather enough data for the algorithm to optimize for sales.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2" className="border-white/10">
                  <AccordionTrigger className="text-left text-lg font-medium text-white hover:text-primary">How long until I see results from a new campaign?</AccordionTrigger>
                  <AccordionContent className="text-white/70 text-base leading-relaxed">
                    Search campaigns can start generating traffic and leads within the first week. However, the algorithm typically needs 2-4 weeks to fully "learn" and optimize your bidding. The best ROAS is usually achieved after month two or three of continuous optimization.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3" className="border-white/10">
                  <AccordionTrigger className="text-left text-lg font-medium text-white hover:text-primary">Do you work with businesses outside of Bangladesh?</AccordionTrigger>
                  <AccordionContent className="text-white/70 text-base leading-relaxed">
                    Yes, I work with clients worldwide. Google Ads is a global platform, and the strategies I use to drive conversions apply across regions. We coordinate via email, WhatsApp, and scheduled video calls to ensure seamless communication regardless of time zones.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </motion.div>
          </div>
        </section>

        {/* SECTION 10 — CONTACT */}
        <section id="contact" className="py-24 bg-white/[0.02] border-t border-white/5 relative overflow-hidden">
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[100px] pointer-events-none" />
          <div className="container mx-auto px-4 md:px-6 relative z-10 max-w-5xl">
            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}
              className="text-center mb-16"
            >
              <motion.h2 variants={fadeInUp} className="text-3xl md:text-4xl font-bold text-white mb-4">Let's Grow Your Business</motion.h2>
              <motion.p variants={fadeInUp} className="text-white/60 text-lg">Fill out the form below or reach out directly.</motion.p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
              <motion.div 
                initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
                className="lg:col-span-3"
              >
                <Card className="bg-white/5 border-white/10">
                  <CardContent className="p-6 sm:p-8">
                    {submitSuccess && (
                      <div
                        role="status"
                        aria-live="polite"
                        className="mb-6 rounded-xl border border-primary/40 bg-primary/10 px-4 py-4 text-sm sm:text-base font-medium text-white shadow-[0_0_20px_rgba(124,58,237,0.25)]"
                        data-testid="form-success-message"
                      >
                        Your message has been sent successfully! I will contact you soon.
                      </div>
                    )}
                    <form onSubmit={handleContactSubmit} className="space-y-6" noValidate>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-white/80">Name</Label>
                          <Input
                            id="name"
                            name="name"
                            required
                            value={formData.name}
                            onChange={handleFieldChange("name")}
                            disabled={isSubmitting}
                            autoComplete="name"
                            className="bg-background/50 border-white/10 focus-visible:ring-primary/50 text-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="business" className="text-white/80">Business Name</Label>
                          <Input
                            id="business"
                            name="businessName"
                            required
                            value={formData.businessName}
                            onChange={handleFieldChange("businessName")}
                            disabled={isSubmitting}
                            autoComplete="organization"
                            className="bg-background/50 border-white/10 focus-visible:ring-primary/50 text-white"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="phone" className="text-white/80">Phone</Label>
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            required
                            value={formData.phone}
                            onChange={handleFieldChange("phone")}
                            disabled={isSubmitting}
                            autoComplete="tel"
                            className="bg-background/50 border-white/10 focus-visible:ring-primary/50 text-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email" className="text-white/80">Email</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            required
                            value={formData.email}
                            onChange={handleFieldChange("email")}
                            disabled={isSubmitting}
                            autoComplete="email"
                            className="bg-background/50 border-white/10 focus-visible:ring-primary/50 text-white"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="message" className="text-white/80">Message / Goals</Label>
                        <Textarea
                          id="message"
                          name="message"
                          required
                          rows={4}
                          value={formData.message}
                          onChange={handleFieldChange("message")}
                          disabled={isSubmitting}
                          className="bg-background/50 border-white/10 focus-visible:ring-primary/50 text-white resize-none"
                        />
                      </div>
                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full h-12 text-base font-semibold shadow-[0_0_15px_rgba(124,58,237,0.3)] hover:shadow-[0_0_25px_rgba(124,58,237,0.5)] disabled:opacity-70"
                      >
                        {isSubmitting ? "Sending..." : "Send Message"}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
                className="lg:col-span-2 flex flex-col justify-center space-y-4"
              >
                <a href="https://wa.me/8801876404801" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-primary/30 transition-all group">
                  <div className="w-12 h-12 rounded-full bg-[#25D366]/20 text-[#25D366] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <FaWhatsapp className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-medium text-white group-hover:text-primary transition-colors">WhatsApp</p>
                    <p className="text-sm text-white/50">+880 1876-404801</p>
                  </div>
                </a>
                
                <a href="mailto:swagatokridas123@gmail.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-primary/30 transition-all group">
                  <div className="w-12 h-12 rounded-full bg-primary/20 text-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                  </div>
                  <div>
                    <p className="font-medium text-white group-hover:text-primary transition-colors">Email</p>
                    <p className="text-sm text-white/50 truncate max-w-[200px]">swagatokridas123@gmail.com</p>
                  </div>
                </a>

                <a href="https://www.linkedin.com/in/swagato-roy01/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-primary/30 transition-all group">
                  <div className="w-12 h-12 rounded-full bg-[#0A66C2]/20 text-[#0A66C2] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <FaLinkedin className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-medium text-white group-hover:text-primary transition-colors">LinkedIn</p>
                    <p className="text-sm text-white/50">Connect with me</p>
                  </div>
                </a>

                <a href="https://www.facebook.com/profile.php?id=61579136242427" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-primary/30 transition-all group">
                  <div className="w-12 h-12 rounded-full bg-[#1877F2]/20 text-[#1877F2] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <FaFacebook className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-medium text-white group-hover:text-primary transition-colors">Facebook</p>
                    <p className="text-sm text-white/50">Follow for updates</p>
                  </div>
                </a>
              </motion.div>
            </div>
          </div>
        </section>

      </main>

      {/* SECTION 11 — FOOTER */}
      <footer className="border-t border-white/10 bg-black/50 py-12">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center md:items-start gap-8 mb-12">
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold text-white mb-2">Swagato Roy</h3>
              <p className="text-primary font-medium mb-4">Google Ads Specialist</p>
              <p className="text-sm text-white/50 max-w-xs">Based in Bangladesh — Working with clients worldwide to drive scalable growth through data-driven advertising.</p>
            </div>
            
            <div className="flex flex-col items-center md:items-end gap-4">
              <div className="flex gap-4">
                <a href="https://wa.me/8801876404801" target="_blank" rel="noopener noreferrer" className="text-white/50 hover:text-[#25D366] transition-colors">
                  <FaWhatsapp className="w-6 h-6" />
                  <span className="sr-only">WhatsApp</span>
                </a>
                <a href="mailto:swagatokridas123@gmail.com" target="_blank" rel="noopener noreferrer" className="text-white/50 hover:text-white transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                  <span className="sr-only">Email</span>
                </a>
                <a href="https://www.linkedin.com/in/swagato-roy01/" target="_blank" rel="noopener noreferrer" className="text-white/50 hover:text-[#0A66C2] transition-colors">
                  <FaLinkedin className="w-6 h-6" />
                  <span className="sr-only">LinkedIn</span>
                </a>
                <a href="https://www.facebook.com/profile.php?id=61579136242427" target="_blank" rel="noopener noreferrer" className="text-white/50 hover:text-[#1877F2] transition-colors">
                  <FaFacebook className="w-6 h-6" />
                  <span className="sr-only">Facebook</span>
                </a>
              </div>
              <div className="text-sm text-white/50 text-center md:text-right">
                <p>swagatokridas123@gmail.com</p>
                <p>+880 1876-404801</p>
              </div>
            </div>
          </div>
          
          <div className="pt-8 border-t border-white/10 text-center text-sm text-white/40 flex flex-col md:flex-row justify-between items-center gap-4">
            <p>© {new Date().getFullYear()} Swagato Roy. All rights reserved.</p>
            <p>Designed for conversion.</p>
          </div>
        </div>
      </footer>

      {/* IMAGE LIGHTBOX (case studies + certificates) */}
      <AnimatePresence>
        {lightbox !== null && (
          <motion.div
            key="lightbox"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            role="dialog"
            aria-modal="true"
            aria-label="Case study image full view"
            onClick={closeLightbox}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4 sm:p-8"
            data-testid="case-study-lightbox"
          >
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); closeLightbox(); }}
              aria-label="Close"
              data-testid="button-lightbox-close"
              className="absolute top-4 right-4 sm:top-6 sm:right-6 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <X className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); showPrev(); }}
              aria-label="Previous image"
              data-testid="button-lightbox-prev"
              className="absolute left-2 sm:left-6 top-1/2 -translate-y-1/2 w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); showNext(); }}
              aria-label="Next image"
              data-testid="button-lightbox-next"
              className="absolute right-2 sm:right-6 top-1/2 -translate-y-1/2 w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            <motion.div
              key={lightbox.index}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-7xl w-full max-h-full flex flex-col items-center"
            >
              <img
                src={lightbox.images[lightbox.index].src}
                alt={lightbox.images[lightbox.index].caption}
                className="max-w-full max-h-[80vh] w-auto h-auto object-contain rounded-lg shadow-2xl"
                data-testid="img-lightbox"
              />
              <div className="mt-4 text-center px-4">
                <p className="text-white text-base sm:text-lg font-medium">
                  {lightbox.images[lightbox.index].caption}
                </p>
                <p className="text-white/50 text-sm mt-1">
                  {lightbox.index + 1} / {lightbox.images.length}
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
